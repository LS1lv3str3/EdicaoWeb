function escrever(){
    document.getElementById("addTexto").innerHTML = "Texto escrito no div da esquerda"
}

function apagarTexto() {
    document.getElementById("addTexto").innerHTML = ""
}